#!/usr/bin/env python3

def main():
    print("Hello World!")

def handler(event, context):
    main()

if __name__ == "__main__":
    main()
